
#include "settings1.h"

int main() {
    int output_file_descriptor;
    int total_data_size;
    int total_written = 0;
    int shared_memory_id;
    int bytes_read, current_buffer_index = 0;
    char read_buffer[CUSTOM_BUFFER_SIZE + 1];
    void *shared_memory_pointer = NULL;
    circular_queue *circular_data_queue;

    // Semaphore identifiers
    int semaphore_sync_id = semget(SYNC_SEM_KEY, 1, 0666 | IPC_CREAT);
    int semaphore_empty_id = semget(EMPTY_SEM_KEY, 1, 0666 | IPC_CREAT);
    int semaphore_full_id = semget(FULL_SEM_KEY, 1, 0666 | IPC_CREAT);
    int semaphore_data_id = semget(DATA_SEM_KEY, 1, 0666 | IPC_CREAT);

    // Accessing the shared memory
    shared_memory_id = shmget((key_t)SHARED_MEM_KEY, sizeof(circular_queue), 0666 | IPC_CREAT);
    if (shared_memory_id == -1) {
        perror("Shared memory access failure");
        exit(EXIT_FAILURE);
    }
    shared_memory_pointer = shmat(shared_memory_id, NULL, 0);
    if (shared_memory_pointer == (void *)-1) {
        perror("Shared memory attachment failure");
        exit(EXIT_FAILURE);
    }
    circular_data_queue = (circular_queue *)shared_memory_pointer;

    // Opening the output file
    output_file_descriptor = open(DEST_FILE, O_WRONLY | O_CREAT | O_TRUNC, 0666);
    if (output_file_descriptor == -1) {
        perror("Output file open failure");
        exit(EXIT_FAILURE);
    }

    // Waiting for the data size semaphore to be available
    semaphore_decrement(semaphore_data_id);
    total_data_size = circular_data_queue->total_size;

    int expected_seq_num = 0;

    while (total_data_size > total_written) {
        semaphore_decrement(semaphore_full_id);
        semaphore_decrement(semaphore_sync_id);

        if (circular_data_queue->segments[current_buffer_index].seq_num != expected_seq_num) {
            fprintf(stderr, "Expected sequence number %d, but received %d\n",
                    expected_seq_num, circular_data_queue->segments[current_buffer_index].seq_num);
            exit(EXIT_FAILURE);
        }

        bytes_read = circular_data_queue->segments[current_buffer_index].length;
        memcpy(read_buffer, circular_data_queue->segments[current_buffer_index].text, bytes_read);
        expected_seq_num += bytes_read;

        semaphore_increment(semaphore_sync_id);
        semaphore_increment(semaphore_empty_id);

        current_buffer_index = (current_buffer_index + 1) % QUEUE_SIZE;

        if (write(output_file_descriptor, read_buffer, bytes_read) != bytes_read) {
            perror("Output file write failure");
            exit(EXIT_FAILURE);
        }
        total_written += bytes_read;
    }

    printf("Total data read from shared memory: %d bytes\n", total_written);

    // Cleanup
    shmdt(shared_memory_pointer);
    close(output_file_descriptor);
    return 0;
}

