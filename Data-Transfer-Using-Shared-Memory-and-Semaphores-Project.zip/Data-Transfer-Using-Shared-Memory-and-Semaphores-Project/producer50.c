// File: data_producer.c
#include "settings1.h"

int main() {
    int source_file_descriptor;
    int shared_memory_identifier;
    int bytes_processed, position_in_queue = 0;
    char working_buffer[CUSTOM_BUFFER_SIZE];
    char file_buffer[SYSTEM_BUFFER_SIZE];
    void *shared_memory_address = NULL;
    circular_queue *circular_data_buffer;

    // Semaphore identifiers with new names
    int sync_semaphore_id = semget(SYNC_SEM_KEY, 1, 0666 | IPC_CREAT);
    int empty_semaphore_id = semget(EMPTY_SEM_KEY, 1, 0666 | IPC_CREAT);
    int full_semaphore_id = semget(FULL_SEM_KEY, 1, 0666 | IPC_CREAT);
    int data_ready_semaphore_id = semget(DATA_SEM_KEY, 1, 0666 | IPC_CREAT);

    // Semaphore initialization with new function names
    if (!semaphore_initialize(sync_semaphore_id, SYNC_SEM_INIT)) {
        perror("Sync semaphore setup failure");
        exit(EXIT_FAILURE);
    }
    if (!semaphore_initialize(empty_semaphore_id, EMPTY_SEM_INIT)) {
        perror("Empty semaphore setup failure");
        exit(EXIT_FAILURE);
    }
    if (!semaphore_initialize(full_semaphore_id, FULL_SEM_INIT)) {
        perror("Full semaphore setup failure");
        exit(EXIT_FAILURE);
    }   
    if (!semaphore_initialize(data_ready_semaphore_id, DATA_SEM_INIT)) {
        perror("Data-ready semaphore setup failure");
        exit(EXIT_FAILURE);
    }

    // Shared memory setup
    shared_memory_identifier = shmget((key_t)SHARED_MEM_KEY, sizeof(circular_queue), 0666 | IPC_CREAT);
    if (shared_memory_identifier == -1) {
        perror("Shared memory allocation failure");
        exit(EXIT_FAILURE);
    }
    shared_memory_address = shmat(shared_memory_identifier, NULL, 0);
    if (shared_memory_address == (void *)-1) {
        perror("Shared memory attachment failure");
        exit(EXIT_FAILURE);
    }
    circular_data_buffer = (circular_queue *)shared_memory_address;

    // Source file opening
    source_file_descriptor = open(SOURCE_FILE, O_RDONLY);
    if (source_file_descriptor == -1) {
        perror("Source file opening failure");
        exit(EXIT_FAILURE);
    }

    // File size retrieval
    struct stat file_stat;
    if (fstat(source_file_descriptor, &file_stat) == -1) {
        perror("Source file stat retrieval failure");
        exit(EXIT_FAILURE);
    }
    circular_data_buffer->total_size = file_stat.st_size;
    printf("Total file size: %d bytes\n", circular_data_buffer->total_size);
    semaphore_increment(data_ready_semaphore_id);

    int sequence_number = 0;

    // File reading and buffer filling
    while ((bytes_processed = read(source_file_descriptor, file_buffer, SYSTEM_BUFFER_SIZE)) > 0) {
        int offset = 0;

        while (bytes_processed > offset) {
            int chunk_size = (bytes_processed - offset > CUSTOM_BUFFER_SIZE) ? CUSTOM_BUFFER_SIZE : bytes_processed - offset;
            memcpy(working_buffer, file_buffer + offset, chunk_size);
            offset += chunk_size;

            semaphore_decrement(empty_semaphore_id);
            semaphore_decrement(sync_semaphore_id);

            circular_data_buffer->segments[position_in_queue].seq_num = sequence_number;
            circular_data_buffer->segments[position_in_queue].length = chunk_size;
            memcpy(circular_data_buffer->segments[position_in_queue].text, working_buffer, chunk_size);
            sequence_number += chunk_size;

            semaphore_increment(sync_semaphore_id);
            semaphore_increment(full_semaphore_id);

            position_in_queue = (position_in_queue + 1) % QUEUE_SIZE;
        }
    }

    printf("Total data written to shared memory: %d bytes\n", circular_data_buffer->total_size);

    // Cleanup and resource deallocation
    shmdt(shared_memory_address);
    close(source_file_descriptor);
    return 0;
}

