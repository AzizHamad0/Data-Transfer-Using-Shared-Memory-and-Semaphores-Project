#ifndef SETTINGS_H
#define SETTINGS_H

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/sem.h>

#define CUSTOM_BUFFER_SIZE 256
#define QUEUE_SIZE 10
#define SYSTEM_BUFFER_SIZE 1024

#define SOURCE_FILE "input.txt"
#define DEST_FILE "output.txt"

#define SYNC_SEM_KEY 1234
#define EMPTY_SEM_KEY 5678
#define FULL_SEM_KEY 9012
#define DATA_SEM_KEY 3456

#define SYNC_SEM_INIT 1
#define EMPTY_SEM_INIT (QUEUE_SIZE - 1)
#define FULL_SEM_INIT 0
#define DATA_SEM_INIT 0

#define SHARED_MEM_KEY 7890

typedef struct {
    int seq_num;
    int length;
    char text[CUSTOM_BUFFER_SIZE];
} shared_data_block;

typedef struct {
    int total_size;
    shared_data_block segments[QUEUE_SIZE];
} circular_queue;


union semaphore_union {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
    struct seminfo *__buf;
};


int semaphore_initialize(int sem_id, int init_val) {
    union semaphore_union sem_union;
    sem_union.val = init_val;
    if (semctl(sem_id, 0, SETVAL, sem_union) == -1) return 0;
    return 1;
}

void semaphore_deallocate(int sem_id) {
    union semaphore_union sem_union;
    if (semctl(sem_id, 0, IPC_RMID, sem_union) == -1)
        fprintf(stderr, "Failed to deallocate semaphore\n");
}

int semaphore_decrement(int sem_id) {
    struct sembuf sem_op;
    sem_op.sem_num = 0;
    sem_op.sem_op = -1;
    sem_op.sem_flg = SEM_UNDO;
    if (semop(sem_id, &sem_op, 1) == -1) {
        fprintf(stderr, "Semaphore decrement failed\n");
        return 0;
    }
    return 1;
}

int semaphore_increment(int sem_id) {
    struct sembuf sem_op;
    sem_op.sem_num = 0;
    sem_op.sem_op = 1;
    sem_op.sem_flg = SEM_UNDO;
    if (semop(sem_id, &sem_op, 1) == -1) {
        fprintf(stderr, "Semaphore increment failed\n");
        return 0;
    }
    return 1;
}

#endif /* SETTINGS_H */

